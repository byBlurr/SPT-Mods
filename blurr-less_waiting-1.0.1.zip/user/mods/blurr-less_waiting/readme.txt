# Config
By default, both reductions are enabled and are set to 10% construction time and 30% craft time.
You can modify the multipliers, just make sure they are 0 or above, no negative numbers.
You can disable either of the reductions by setting them to false.

A copy of the default config is below:
{
    "reduceConstruction": true,
    "constructionMultiplier": 0.1,
    "reduceCrafting": true,
    "craftingMultiplier": 0.3
}

# Future Updates
I will only actively update the mod when I am playing the game myself. If it hasn't been updated in a while, message me on Discord (imrblurr).
If you have any feature requests, that fit the use case for the mod, message me. I will not add features for the sake of it, if its unrelated bloat then it needs to be its own mod. (I can't stand mods that are for one thing but do 5 other unwanted things...)






Contact me on Discord, if you NEED to... imrblurr