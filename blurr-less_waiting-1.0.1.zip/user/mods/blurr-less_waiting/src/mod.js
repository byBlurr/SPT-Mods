class cfg

{
    postDBLoad(container) {
        let debug = false; // Enable for extra console prints

        const logger = container.resolve("WinstonLogger");
        let modConfig = require("../configuration/config.json");

        const databaseServer = container.resolve("DatabaseServer");
        const tables = databaseServer.getTables();

        // Construction times
        if (modConfig.reduceConstruction == true) {
            logger.info('Construction reduction enabled.');
            const areas = tables.hideout.areas;
            for (let _area in areas) {
                if ("stages" in areas[_area]) {
                    const stages = areas[_area].stages;
                    for (let stage in stages) {
                        if ("constructionTime" in stages[stage]) {
                            if (stages[stage].constructionTime > 0) {
                                stages[stage].constructionTime = stages[stage].constructionTime * modConfig.constructionMultiplier;
                                if (debug) {
                                    logger.info('Reduced construction time of hideout area.');
                                }
                            }
                        }
                    }
                }
            }
        } else {
            logger.info('Construction reduction disabled.');
        }
        

        // Craft times
        if (modConfig.reduceCrafting == true) {
            logger.info('Crafting reduction enabled.');
            const crafts = tables.hideout.production;
            for (let _craft in crafts) {
                if ("productionTime" in crafts[_craft]) {
                    crafts[_craft].productionTime = crafts[_craft].productionTime * modConfig.craftingMultiplier;
                    if (debug) {
                        logger.info('Reduced craft time of item.');
                    }
                }
            }
        } else {
            logger.info('Crafting reduction disabled.');
        }
    }
}

module.exports = {
    mod: new cfg
};