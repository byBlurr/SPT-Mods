class cfg

{
    postDBLoad(container)
    {
        let debug = false; // Enable for extra console prints

        const logger = container.resolve("WinstonLogger");
        let modConfig = require("../configuration/config.json");

        if (modConfig.enabled == true)
        {
            let ammoIds = require("../data/ammo.json");
            const databaseServer = container.resolve("DatabaseServer");
            const tables = databaseServer.getTables();

            const items = tables.templates.items;
            const locales = tables.locales.global;
            
            for (let _ammo in ammoIds)
            {
                let _id = ammoIds[_ammo];
                let desc = "";
                let canSell = items[_id]._props.CanSellOnRagfair;

                if (modConfig.showFleaColor == true)
                {
                    if (canSell == false)
                    {
                        items[_id]._props.BackgroundColor = "red";
                    }
                }

                if (modConfig.showDamagePenetration == true)
                {
                    let pen = items[_id]._props.PenetrationPower;
                    let dam = items[_id]._props.Damage;
                    desc = "Penetration: " + pen + "        Damage: " + dam + "        ";
                }

                if (modConfig.showProjectileCount == true)
                {
                    if ("buckshotBullets" in items[_id]._props)
                    {
                        let projectiles = items[_id]._props.ProjectileCount;
                        let dam = items[_id]._props.Damage;
                        if (projectiles > 1)
                        {
                            desc = desc + "Projectiles: " + projectiles + " (" + (projectiles * dam) + " max dmg)        ";
                        }
                    }
                }

                if (modConfig.showFleaPrice == true && canSell == true)
                {
                    let price = 0;
                    desc = desc + "Flea: " + price;
                }

                if (modConfig.showDamagePenetration == true || modConfig.showFleaPrice == true)
                {
                    for (let _loc in locales)
                    {
                        locales[_loc][_id + " Description"] = desc + "\n\n" + locales[_loc][_id + " Description"];
                    }
                }
            }
            
            logger.info("[AmmoInformation] Ammo items updated with helpful info.")
        }
    }
}

module.exports = {
    mod: new cfg
};