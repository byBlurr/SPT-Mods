# Config (configurations/config.json)
enabled - Set to false to disable the mod without removing from your files
showFleaColor - Ammo that can not be sold on the flea will have a red background. This helps you see ammo you should definitely take. Disable by setting to false.
showDamagePenetration - This will put the damage and penetration values into the ammo items description.
showProjectileCount - This will show how many projectiles are shot from a buckshot round in the description.
showFleaPrice - Keep as false, this is a future maybe...


# Copy of default config
{
    "enabled": true,
    "showFleaColor": true,
    "showDamagePenetration": true,
    "showProjectileCount": true,
    "showFleaPrice": false
}